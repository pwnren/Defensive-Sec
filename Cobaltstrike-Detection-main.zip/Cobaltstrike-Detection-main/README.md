# Cobaltstrike-Detection
This repo will contain the core detection, only for Cobaltstrike's leaked versions. Non-leaked version detections wont be shared
